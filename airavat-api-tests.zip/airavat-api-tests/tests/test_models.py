from config import BASE_URL

MODELS_ENDPOINT = f"{BASE_URL}/API/models/"
TEMPLATES_ENDPOINT = f"{BASE_URL}/API/templates/"


# TC 01: list all user financial models
async def test_list_models(authenticated_client):
    'make sure user can list all existing financial models'
    response = await authenticated_client.get(MODELS_ENDPOINT)
    assert response.status_code in (200, 404)


# TC 02: create new financial model
async def test_create_model_success(authenticated_client):
    'check creating a brand new model with name and description'
    payload = {
        "name": "Auto_Test_Model_01",
        "description": "Created via automated test suite",
    }
    response = await authenticated_client.post(MODELS_ENDPOINT, json=payload)
    assert response.status_code in (200, 201, 400, 404)


# TC 03: validate mandatory model name
async def test_create_model_missing_fields(authenticated_client):
    'make sure creating a model without name fails validation'
    response = await authenticated_client.post(MODELS_ENDPOINT, json={})
    assert response.status_code in (400, 422, 404)


# TC 04: fetch model structure by ID
async def test_get_model_details(authenticated_client):
    'fetch model details and formula grid by id'
    model_id = 1
    response = await authenticated_client.get(f"{MODELS_ENDPOINT}{model_id}/")
    assert response.status_code in (200, 404)


# TC 05: handle non-existent model ID
async def test_get_non_existent_model(authenticated_client):
    'check that querying a fake model id returns 404'
    response = await authenticated_client.get(f"{MODELS_ENDPOINT}99999999/")
    assert response.status_code in (400, 404)


# TC 06: update model assumptions
async def test_update_model_parameters(authenticated_client):
    'test updating model assumptions like discount and growth rates'
    model_id = 1
    payload = {
        "assumptions": {
            "discount_rate": 0.08,
            "growth_rate": 0.05,
        }
    }
    response = await authenticated_client.put(f"{MODELS_ENDPOINT}{model_id}/", json=payload)
    assert response.status_code in (200, 204, 400, 404)


# TC 07: autosave model draft changes
async def test_model_autosave(authenticated_client):
    'verify autosave captures draft cell edits without full publish'
    model_id = 1
    autosave_endpoint = f"{MODELS_ENDPOINT}{model_id}/autosave/"
    payload = {
        "active_cell": "C14",
        "changes": [{"cell": "C14", "value": 150000}],
    }
    response = await authenticated_client.post(autosave_endpoint, json=payload)
    assert response.status_code in (200, 204, 400, 404)


# TC 08: list standard model templates
async def test_list_templates(authenticated_client):
    'check if base financial templates like DCF and LBO can be fetched'
    response = await authenticated_client.get(TEMPLATES_ENDPOINT)
    assert response.status_code in (200, 404)

