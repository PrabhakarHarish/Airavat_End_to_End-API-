import io
from config import BASE_URL

UPLOAD_ENDPOINT = f"{BASE_URL}/API/excel/upload/"
VALIDATE_PNL_ENDPOINT = f"{BASE_URL}/API/excel/validate-pnl/"
CONVERT_MODEL_ENDPOINT = f"{BASE_URL}/API/excel/convert-to-model/"
MODELS_ENDPOINT = f"{BASE_URL}/API/models/"
EXTRACT_PICTURE_ENDPOINT = f"{BASE_URL}/API/excel/extract-picture-data/"


# TC 01: upload valid Excel template file
async def test_upload_excel_template(authenticated_client):
    'check uploading a valid .xlsx financial template file'
    fake_excel_bytes = io.BytesIO(b"PK\x03\x04fake_excel_stream")
    files = {
        "file": ("Base_Template.xlsx", fake_excel_bytes, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
    }
    response = await authenticated_client.post(UPLOAD_ENDPOINT, files=files)
    assert response.status_code in (200, 201, 400, 404)


# TC 02: reject unsupported file extensions
async def test_upload_unsupported_file_format(authenticated_client):
    'make sure uploading unsupported formats like .exe gets rejected'
    fake_exe_bytes = io.BytesIO(b"MZ\x90\x00executable_header")
    files = {
        "file": ("malicious_file.exe", fake_exe_bytes, "application/octet-stream")
    }
    response = await authenticated_client.post(UPLOAD_ENDPOINT, files=files)
    assert response.status_code in (400, 415, 422, 404)


# TC 03: validate P&L sheet data consistency
async def test_validate_pnl_data_consistency(authenticated_client):
    'verify P&L reconciliation passes when numbers and math line up'
    payload = {
        "statement_type": "PNL",
        "periods": ["2024", "2025", "2026"],
        "line_items": {
            "Revenue": [1000, 1200, 1400],
            "COGS": [400, 480, 560],
            "GrossProfit": [600, 720, 840],
        }
    }
    response = await authenticated_client.post(VALIDATE_PNL_ENDPOINT, json=payload)
    assert response.status_code in (200, 400, 404)


# TC 04: detect broken calculations in P&L sheet
async def test_validate_pnl_discrepancy_detected(authenticated_client):
    'check that bad P&L math (e.g. wrong gross profit) gets caught'
    broken_payload = {
        "statement_type": "PNL",
        "line_items": {
            "Revenue": [1000],
            "COGS": [400],
            "GrossProfit": [9999],  # intentional mismatch: 1000 - 400 != 9999
        }
    }
    response = await authenticated_client.post(VALIDATE_PNL_ENDPOINT, json=broken_payload)
    assert response.status_code in (400, 422, 404)


# TC 05: convert ingested spreadsheet to model
async def test_convert_excel_to_model(authenticated_client):
    'convert parsed excel data into the system model structure'
    payload = {"template_id": 1, "model_name": "Converted_From_Excel"}
    response = await authenticated_client.post(CONVERT_MODEL_ENDPOINT, json=payload)
    assert response.status_code in (200, 201, 400, 404)


# TC 06: export model to downloadable Excel file
async def test_export_model_to_excel(authenticated_client):
    'make sure user can export the completed model back into an excel sheet'
    model_id = 1
    export_endpoint = f"{MODELS_ENDPOINT}{model_id}/export/excel/"
    response = await authenticated_client.get(export_endpoint)
    assert response.status_code in (200, 404)


# TC 07: extract picture and chart data
async def test_extract_picture_data(authenticated_client):
    'check pulling out embedded charts and image metadata from sheets'
    payload = {"model_id": 1}
    response = await authenticated_client.post(EXTRACT_PICTURE_ENDPOINT, json=payload)
    assert response.status_code in (200, 400, 404)

