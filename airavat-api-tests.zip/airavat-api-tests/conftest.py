import pytest_asyncio
from utils.api_client import get_authenticated_client   ## Import our login helper function that logs in and returns an authenticated client


@pytest_asyncio.fixture(scope="function")
async def authenticated_client():

    client, response = await get_authenticated_client()  #Hand the authenticated client over to whichever test asked for it ,and pause here until that test finishes running
    yield client
    await client.aclose()