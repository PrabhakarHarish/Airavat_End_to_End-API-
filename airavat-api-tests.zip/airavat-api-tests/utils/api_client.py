import httpx            # imports the HTTPX library for making asynchronous HTTP requests
from config import LOGIN_ENDPOINT, USERNAME, PASSWORD    #The login urls and credentials are imported from the config.py file


async def get_authenticated_client() -> tuple[httpx.AsyncClient, httpx.Response]:

    # verify=False because this is an internal/self-signed cert environment
    client = httpx.AsyncClient(verify=False)

    files = {
        "username": (None, USERNAME),
        "password": (None, PASSWORD),
    }

    #actual response call is done to the login endpoint with the provided username and password to the server.
    response = await client.post(LOGIN_ENDPOINT, files=files)

        ## If the server responded with an error status (4xx/5xx),
    # stop here and raise an exception
    # instead of silently continuing with a failed login
    response.raise_for_status()

    return client, response