import os
from dotenv import load_dotenv

load_dotenv()

BASE_URL = os.getenv("BASE_URL", "https://10.20.11.244:3000")
USERNAME = os.getenv("AIRAVAT_USERNAME")
PASSWORD = os.getenv("AIRAVAT_PASSWORD")

LOGIN_ENDPOINT = f"{BASE_URL}/API/login/"